# 📊 Actualización Diaria de Fondos de Inversión
## Guía de Configuración — Paso a Paso

---

## ¿Qué hace este sistema?

Cada mañana de lunes a viernes (8:30h Madrid), los servidores gratuitos
de GitHub ejecutan automáticamente un script que:

1. Descarga el precio (NAV) actualizado de tus 36 fondos
2. Calcula la rentabilidad YTD, 1 mes, 3 meses y 1 año
3. Actualiza el rating Morningstar, duración y YTM
4. Te envía el Excel por email con todos los datos frescos

**Coste total: 0 €/mes** — GitHub Actions es gratuito hasta 2.000
minutos/mes (este script usa ~5 minutos/día).

---

## PASO 1 — Crear cuenta en GitHub (si no tienes)

1. Ve a **https://github.com** y haz clic en **Sign up**
2. Elige un nombre de usuario y contraseña
3. Confirma tu email

---

## PASO 2 — Crear el repositorio

1. Una vez dentro de GitHub, haz clic en el botón verde **New** (arriba a la izquierda)
2. Rellena:
   - **Repository name:** `fondos-inversion`
   - Selecciona **Private** (para que nadie más vea tus datos)
3. Haz clic en **Create repository**

---

## PASO 3 — Subir los archivos

Tienes dos opciones:

### Opción A (sencilla) — Desde el navegador

1. En tu repositorio recién creado, haz clic en **uploading an existing file**
2. Arrastra estos archivos desde tu ordenador:
   - `actualizar_fondos.py`
   - `requirements.txt`
   - `fondos_inversion.xlsx`  ← el Excel que te generé
3. También crea la carpeta `.github/workflows/` y sube dentro:
   - `actualizar_fondos.yml`
4. Haz clic en **Commit changes**

### Opción B — Con Git (si lo tienes instalado)

```bash
git clone https://github.com/TU_USUARIO/fondos-inversion.git
cd fondos-inversion
# Copia los archivos aquí
git add .
git commit -m "Configuración inicial"
git push
```

---

## PASO 4 — Configurar Gmail para enviar emails automáticos

GitHub necesita una contraseña especial (no tu contraseña normal) para
poder enviar emails desde tu cuenta Gmail.

1. Ve a **https://myaccount.google.com/security**
2. Activa la **Verificación en 2 pasos** (si no la tienes)
3. Busca **Contraseñas de aplicaciones**
4. En "Seleccionar aplicación" elige **Correo**
5. En "Seleccionar dispositivo" elige **Otro** → escribe `GitHub Fondos`
6. Haz clic en **Generar**
7. Guarda la contraseña de 16 caracteres que aparece (tipo: `abcd efgh ijkl mnop`)

---

## PASO 5 — Añadir las credenciales a GitHub (Secrets)

Las credenciales se guardan cifradas en GitHub — nadie puede verlas.

1. En tu repositorio, haz clic en **Settings** (arriba a la derecha)
2. En el menú izquierdo, haz clic en **Secrets and variables** → **Actions**
3. Haz clic en **New repository secret** y añade estos tres:

| Nombre del Secret  | Valor                              |
|--------------------|------------------------------------|
| `EMAIL_REMITENTE`  | tu dirección Gmail (ej: tuemail@gmail.com) |
| `EMAIL_PASSWORD`   | la contraseña de app de 16 caracteres      |
| `EMAIL_DESTINO`    | email donde quieres recibir el Excel       |

---

## PASO 6 — Probar que funciona

1. En tu repositorio, haz clic en **Actions** (menú superior)
2. Haz clic en el workflow **📊 Actualizar Fondos Diariamente**
3. Haz clic en **Run workflow** → **Run workflow** (botón verde)
4. Espera ~5 minutos
5. Si aparece un círculo ✅ verde → ¡funcionó! Revisa tu email.
6. Si aparece ❌ rojo → haz clic para ver el error (normalmente es una
   credencial mal copiada)

---

## Horario de ejecución

El script corre automáticamente **lunes a viernes a las 8:30h (Madrid)**.

Para cambiar la hora, edita esta línea en `actualizar_fondos.yml`:
```yaml
- cron: "30 7 * * 1-5"   # 07:30 UTC = 08:30 Madrid (invierno)
```

En verano (horario CEST, UTC+2), cambia a:
```yaml
- cron: "30 6 * * 1-5"   # 06:30 UTC = 08:30 Madrid (verano)
```

---

## ¿Qué datos se actualizan y de dónde vienen?

| Dato              | Fuente          | Frecuencia |
|-------------------|-----------------|------------|
| NAV / Precio      | Yahoo Finance   | Diaria     |
| Rentab. YTD       | Yahoo Finance   | Diaria     |
| Rentab. 1M, 3M, 1Y| Yahoo Finance   | Diaria     |
| Rating Morningstar| Morningstar ES  | Diaria     |
| Duración          | Morningstar ES  | Diaria     |
| YTM               | Morningstar ES  | Diaria     |

> **Nota:** No todos los fondos tienen ticker en Yahoo Finance.
> Los fondos sin ticker solo se actualizan vía Morningstar.
> Puedes ampliar el mapeo `ISIN_A_TICKER` en `actualizar_fondos.py`.

---

## Añadir nuevos fondos

1. Abre `actualizar_fondos.py`
2. Busca la sección `ISIN_A_TICKER` y añade el ISIN y ticker de Yahoo
3. Busca la sección `ISIN_A_MORNINGSTAR` y añade el ID de Morningstar
   (búscalo en la URL de la ficha del fondo en morningstar.es)
4. Añade la fila al Excel manualmente
5. Haz commit → el siguiente día ya se actualizará automáticamente

---

## Solución de problemas frecuentes

| Problema                          | Solución                                      |
|-----------------------------------|-----------------------------------------------|
| No llega el email                 | Revisa la contraseña de app de Gmail (paso 4) |
| El workflow falla con error 403   | Regenera la contraseña de app                 |
| Algún fondo no se actualiza       | Ese fondo no tiene ticker/ID configurado      |
| El Excel llega vacío              | Comprueba que `fondos_inversion.xlsx` está en el repo |
| Quiero ejecutarlo ahora           | Actions → Run workflow (paso 6)               |
